function upper(strings,...values) {}

var name = "kyle",
	twitter = "getify",
	classname = "es6 workshop";

console.log(
	`Hello ____ (@____), welcome to the ____!` ===
	"Hello KYLE (@GETIFY), welcome to the ES6 WORKSHOP!"
);
